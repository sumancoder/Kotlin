package learnKotlin

fun playingWithCollectionsInKotlin() {
	// class java.util.HashSet
	val set 	= hashSetOf(10, 50, 60, 10, 90) 
	// class java.util.ArrayList
	val list 	= arrayListOf(10, 50, 60, 10, 90)
	// class java.util.HashMap
	val map		= hashMapOf(1 to "One", 10 to "Ten", 7 to "Seven")

	println(set)
	println(set.javaClass)
	println(list)
	println(list.javaClass)
	println(map)
	println(map.javaClass)

	// class java.util.Arrays$ArrayList
	val strings = listOf("First", "Second", "Tenth", "Fifth")
	println(strings)
	println(strings.javaClass)
	println(strings.last())

	// class java.util.LinkedHashSet
	val numbers = setOf(10, 14, 20, 90, 20)
	println(numbers)
	println(numbers.javaClass)
	println(numbers.maxOrNull())
}

// [10, 50, 90, 60]
// [10, 50, 60, 10, 90]
// {1=One, 10=Ten, 7=Seven}
// [First, Second, Tenth, Fifth]
// Fifth
// [10, 14, 20, 90]
// 90

//________________________________________________

fun <T> joinToString(
	collection: Collection<T>,
	separator: String,
	prefix: String,
	postfix: String
) : String {
	val result = StringBuilder(prefix)

	for( (index, element) in collection.withIndex() ) {
		if (index > 0) result.append(separator)
		result.append(element)
	}

	result.append(postfix)
	return result.toString()
}

fun playWithJoinToString() {
	val list = listOf(10, 20, 30, 40, 60, 80, 90)
	println(joinToString(list, " ; ", " ( ", " ) "))
	println(joinToString(list, " , ", " [ ", " ] "))
}

//________________________________________________


fun lastChar(string: String): Char {
	return string.get( string.length - 1 )
}

fun playWithLastChar() {
	println( lastChar("Kotlin") )
	println( lastChar("Hello World!") ) 
}

// Extension Function
//		Add Behaviour In Existing Type
// lastCharater is a Extention Fuction On Type String
//		means It is available Member Function wherever you use String Objects

fun String.lastCharacter(): Char {
	return this.get( this.length - 1 )
}

fun playWithLastCharacter() {
	println( "Kotlin".lastCharacter() )
	println( "Hello World!".lastCharacter() ) 
}

//________________________________________________

fun <T> Collection<T>.joinToStringExtention(
	separator: String = ", ",
	prefix: String = "",
	postfix: String = ""
) : String {
	val result = StringBuilder(prefix)

	for ( (index, element) in this.withIndex() ) {
		if (index > 0) result.append(separator)
		result.append(element)
	}

	result.append(postfix)
	return result.toString()
}

fun playWithJoinToStringExtension() {
	val list = listOf(10, 20, 30, 40, 60, 80, 90)
	println( list.joinToStringExtention(" ; ", " ( ", " ) ") )
	println( list.joinToStringExtention(", ", " [ ", " ] ") ) 
	println( list.joinToStringExtention() )
	println( list.joinToStringExtention(" : ") )

	val list1 = arrayListOf(10, 50, 60, 10, 90)
	println(list1.joinToStringExtention(" ; ", " ( ", " ) "))
	println(list1.joinToStringExtention(", ", " [ ", " ] ") ) 
	println(list1.joinToStringExtention())
	println(list1.joinToStringExtention(" : "))
}

//________________________________________________


// fun Collection<String>.join(
// 	separator: String = ";",
// 	prefix: String =" " ,
// 	postfix: String = ""
// ) = joinToStringExtension(separator, prefix, postfix)

// Creating Newer and Better APIs
fun Collection<String>.join(
	separator: String = ", ",
	prefix: String = "",
	postfix: String = ""
) = joinToStringExtention(separator, prefix, postfix)

fun playWithCollectionJoin() {
	val list = listOf("Ding", "Dong", "Ting", "Tong")
	println( list.join(" ; ", " ( ", " ) ") )
	println( list.join(", ", " [ ", " ] ") ) 
	println( list.join() )
	println( list.join(" : ") )

	val list1 = arrayListOf("Ping", "Pong", "AAAA", "BBBB")
	println( list1.join(" ; ", " ( ", " ) "))
	println( list1.join(", ", " [ ", " ] ") ) 
	println( list1.join())
	println( list1.join(" : "))	
}


fun playWithStrings() {
	println("12.354-7.A".split("\\.|-".toRegex()))
	println("12.354-7.A".split(".","-"))
}

fun parsePath(path: String){
	val directory = path.substringBeforeLast("/")
	val fullName= path.substringAfterLast("/")

	val fileName= fullName.substringBeforeLast(".")
	val fileExtension= fullName.substringAfterLast(".")


	println("Directory : $directory")
	println("fileName : $fileName")

}


fun playWithParsing(){
	println(parsePath("/Users/Suman/file/java"))
}



fun parseWithTripleQuote(path: String){
	val regex= """(.+)/(.+)(.+)""".toRegex()

	val matchResult= regex.matchEntire(path)
	if(matchResult != null) {
	val(directory,filename,extension) = matchResult.destructured

     println("Directory : $directory")
     println("fileName : $filename")

	}
}


fun playWithParsing1(){
	println(parseWithTripleQuote("/Users/Suman/file/java"))
}


class User(val id: Int, val name: String, val address: String)

fun saveUser(user: User){
	if(user.name.isEmpty()){
	throw IllegalArgumentException("can not save user: EMpty name")
	}

	if(user.address.isEmpty()){
	throw IllegalArgumentException("can not save user: Address name")
	}

	println("Saved user succesfully")
	}


fun playWithSaveUser(){
	saveUser(User(10,"T","DELHI"))
	//saveUser(User(10,"","BANG"))
	//saveUser(User(10,"Tx",""))
}

//-----------------Local Functions------------
// Only Accesible inside enclosing functions

fun saveUserWithLocalValidationFunction(user: User){

fun validate(user: User,value: String,  fieldName: String){
	if(value.isEmpty())
	throw IllegalArgumentException("can not save user: EMpty name")
}

validate(user,user.name,"Name")
validate(user,user.address,"Address")


	println("Saved user succesfully")
	}


fun playWithSaveUserValidate(){
	saveUserWithLocalValidationFunction(User(10,"T","DELHI"))
	//saveUser(User(10,"","BANG"))
	//saveUser(User(10,"Tx",""))
}



//-----------------------------------------------
//local functions are nested
fun saveUserWithLocalValidationFunction1(user: User){

fun validate(value: String,  fieldName: String){
	if(value.isEmpty())
	throw IllegalArgumentException("can not save user: EMpty name")
}

validate(user.name,"Name")
validate(user.address,"Address")


	println("Saved user succesfully")
	}


fun playWithSaveUserValidate1(){
	saveUserWithLocalValidationFunction(User(10,"T","DELHI"))
	//saveUser(User(10,"","BANG"))
	//saveUser(User(10,"Tx",""))
}

//________________________________________________
//Extension function and local function
fun User.validateBeforeSave(){

fun validate(value: String,  fieldName: String){
	if(value.isEmpty())
	throw IllegalArgumentException("can not save user: EMpty name")
}

validate(name,"Name")
validate(address,"Address")


	println("Saved user succesfully")
	}


fun playWithSaveUserValidate2(){
	User(10,"T","DELHI").validateBeforeSave()
	//User(10,"","BANG").validateBeforeSave()
	//saveUser(User(10,"Tx",""))
}

//_____________________________________
//Extension properties
val String.lastChar: Char
get()= get(length-1)

var StringBuilder.lastChar: Char
  get()= get(length-1)
  set(value: Char){
  this.setCharAt(length-1,value)
  }

  fun playWithExtensionProperties()
{
	
	println("kotlin".lastChar)
	val string = StringBuilder("Heyooo")
	println(string)
	string.lastChar='%'
	println(string)
}
//________________________________________________
//________________________________________________
//________________________________________________

fun main() {
	println("\nFunction : playingWithCollectionsInKotlin")
	playingWithCollectionsInKotlin()

	println("\nFunction : playWithJoinToString")
	playWithJoinToString()

	println("\nFunction : playWithLastChar")
	playWithLastChar()

	println("\nFunction : playWithLastCharacter")
	playWithLastCharacter()
	
	println("\nFunction : playWithJoinToStringExtension")
	playWithJoinToStringExtension()

	println("\nFunction : playWithCollectionJoin")
	playWithCollectionJoin()
	
	 println("\nFunction : parsePath")
	 playWithParsing()



	 println("\nFunction : parseWithTripleQuote")
	 playWithParsing1()
	 println("\nFunction : saveUser")
	 playWithSaveUser()
	 println("\nFunction : saveUserWithLocalValidationFunction ")
	 playWithSaveUserValidate()
	 println("\nFunction : saveUserWithLocalValidationFunction 1")
	 playWithSaveUserValidate1()
	 println("\nFunction : validateBeforeSave")
	 playWithSaveUserValidate2()
	 println("\nFunction : playWithExtensionProperties")
	 playWithExtensionProperties()
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}