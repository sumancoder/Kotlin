package learnKotlin

//_______________________________________________________________________

// In Kotlin Types Are NonNullable By Default
//		You Can't Assign null Value To It
//			e.g String, Int, Float, Person and so on...
//		In Kotlin For Every Non Nullable Type There Exists Nullable Type
//			By Suffixing ? To Type
//			e.g. String?, Int?, Float?, Person? and so on...
//			These Are Also Optional Types
//			e.g.
// In Java Types Are Nullable By Default
//		You CanAssign null Value To It

// Experiment With Following Code. Moment Done, Type Done In Chat Window

fun playWithNullabilityAndMutability() {
	// MUTABLE
	// String is Non-Nullable Type
	var string: String  = "Hello World!"
	println(string)

	string = "Kotlin Is Awesome!!!"
	println(string)

	// error: null can not be a value of a non-null type String
	// string = null
	// println(string)

	// IMMUTABLE
	// Int is Non-Nullable Type	
	val number: Int = 9898
	println(number)
	// number = 9000 // error: val cannot be reassigned
	// println(number)

	// String? is Nullable Type
	var stringAgain: String? = "Hello World!"
	println(stringAgain)
	stringAgain = null
	println(stringAgain)

	var numberAgain: Int? = 9898
	println(numberAgain)
	numberAgain = null
	println(numberAgain)
}

//_______________________________________________________________________

fun strLenSafe(string: String?) : Int = if( string != null ) string.length else 0

fun playWithNullableTypes() {
	var string: String? = null

	println(strLenSafe(string))
	println(strLenSafe("Welcome!"))	

	// Safe Access Operator
	// In This Expression string?.uppercase(), 
	//	If string is null
	//		Then Whole Of The Expression Evaluates to null
	//  Otherwise string !is null
	//		Then Whole Of The Expression Evaluates to string.uppercase()

	var upperCases = string?.uppercase() 
	// Compiler Will Generate Following Code For Above Expression
	// val upperCases: String? = if( string != null ) string.uppercase() else null
	println(upperCases)
	string = "Hello World!"	
	// upperCases = string?.uppercase()
	//println(upperCases)
	println(string)
}

//_______________________________________________________________________
// Experiment With Following Code. Moment Done, Type Done In Chat Window

class Employee(val name: String, val manager: Employee?)

fun managerName(employee: Employee): String? = employee.manager?.name

fun safeCallOperator1() {
    val ceo = Employee("Da Boss", null)
    val developer = Employee("Bob Smith", ceo)
    println(managerName(developer))
    println(managerName(ceo))
}

//_______________________________________________________________________

// fun strLenSafe(string: String?) : Int = if( string != null ) string.length else 0

// Above Function Can Be Written With Elvis Operator As Follows
// ?: Elvis Operator
// 		Followed By Default Value
// In Following Example If sting is null
//		string?.length Expression Evaluates To null
//		Then Default Value Followed By Elvis Operator is Returned

fun strLenSafe1(string: String?) : Int = string?.length ?: 0

fun playWithNullableTypes1() {
	var string: String? = null

	println(strLenSafe1(string))
	println(strLenSafe1("Welcome!"))	

	// !! Unsafe Access Operator: Used In Rarest Rare Scenarios
	// Exception in thread "main" java.lang.NullPointerException
	val data = string!! 
	println(data)
}

data class Person(val name: String, val age: Int)

fun playWithTypeCasting() {
	val something: Any? = Person("Alice Carols", 20)

	// Safe Type Cast
	// 		It Will Try To Do Type Cast
	//		If Type Casting Succeeds Than Return Type Casted Object
	//		Otherwise Return null
	val person: Person? = something as? Person

	println(person?.name) // error: unresolved reference: name
	println(person?.age)  // error: unresolved reference: age

	// Use It When You Are 100% Sure
	val person1: Person = something as Person

	println(person1.name) // error: unresolved reference: name
	println(person1.age)  // error: unresolved reference: age
}

//_______________________________________________________________________
//_______________________________________________________________________
//_______________________________________________________________________
//_______________________________________________________________________

// Experiment With Following Code. Moment Done, Type Done In Chat Window

fun main() {
	println("\nFunction : playWithNullabilityAndMutability")
	playWithNullabilityAndMutability()

	println("\nFunction : playWithNullableTypes")
	playWithNullableTypes()

	println("\nFunction : playWithNullableTypes1")
	playWithNullableTypes1()

	println("\nFunction : playWithTypeCasting")
	playWithTypeCasting()

	// println("\nFunction : ")		
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")		
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")		
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")		
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")		
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")		
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")		
}