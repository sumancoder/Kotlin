package learnKotlin

//data class Person(val name: String, val age: Int)

fun findTheOldest(people: List<Person>) {
	var maxAge=0 
	var theOldest : Person ? = null

	for (person in people){
	if(person.age> maxAge){
	maxAge = person.age
	theOldest = person
	}
	}
	println(theOldest) 
}


fun playWithTheFindOlderst()
{
	val people = listOf(Person("Alice", 29 ),Person("BIB", 77 ))

    findTheOldest(people)
}

//---------------------------
fun playWithLambda(){
	val sum = {x: Int , y: Int -> x + y }
	var result = sum (10,20)
    
    println(result)

    var result1 = sum (10,201)
    
    println(result1)

    var result2 = sum (101,20)
    
    println(result2)

    val people = listOf(Person("Alice", 29 ),Person("BIB", 77 ))

    val names = people.joinToString(separator= " ",
    transform = {person: Person -> person.name})

    println(names)
}








//---------------------------

fun sum(x: Int, y: Int) = x + y

fun sub(x: Int,y: Int) : Int { return x -y }

fun calculator(x: Int, y: Int , operation: (Int, Int) -> Int) : Int {
	
	return operation(x,y)
}

fun playWithCalculator() {
	val a = 20
	val b=10
	var result: Int

	result = calculator(a,b, ::sum)
	println("Result: $result")

	result = calculator(a,b, ::sub)
	println("Result: $result")

	val sumLambda = {x: Int, y: Int -> x  +  y}
	val subLambda = {x: Int, y: Int -> x  - y}

	result = calculator(a, b, sumLambda)
	println("Result: $result")

	result = calculator(a, b, subLambda)
	println("Result: $result")


	val something = ::sum
	result = something(300,70)

	println("Result: $result")


	val dosomething = ::calculator
	result = dosomething(300,70,sumLambda)

	println("Result: $result")



}



//---------------------------

data class Person(val name: String, val age: Int)


data class Person1(val firstName: String, val lastName: String,
val age: Int, val gender: Char)

fun playWithLambdaExp(){
	  val people = listOf(Person("Alice", 29 ),Person("BIB", 77 ))
	  
	  val names = people.joinToString(separator= " : ", transform = {
	  person: Person -> person.name
	  })

	  val ages = people.joinToString(separator= " : ", transform = {
	  person: Person -> person.age.toString()
	  })

	  println(ages)


	  val people1 = listOf(Person1("Alice","carol" ,29, 'F' ),Person1("BOB","Dylon" ,77,'M' ))


	  val firstnames = people1.joinToString(separator= " $ ", transform = {
	  person: Person1 -> person.lastName + " " + person.firstName
	  })

	  println(firstnames)

	   val lastnames = people1.joinToString(separator= " * ", transform = {
	  person: Person1 -> person.firstName + " " + person.lastName
	  })

	  println(lastnames)


	  val respectedNames = people1.joinToString(separator= " ^ ", transform = {
	  person: Person1 -> if (person.gender == 'M') " Mr. " + person.firstName
	  else "Ms. " + person.firstName
	  })

	  println(respectedNames)


	  val sumLambda = { x: Int , y: Int -> 
	  println("adding values of $x and $y") 
	  x + y 
	  }

	  println(sumLambda(10,100))

}

//---------------------------

fun printMessageWithPrefix( messages : Collection<String>,  prefix: String){
  
  println("Messages List First time ")
  messages.forEach({ message: String -> println("$prefix $message")})

  println("Messages List Second time ")
  messages.forEach({println("$prefix $it")})

  println("Messages List Third time ")
  messages.forEach{ println("$prefix $it")}

  println("Messages List fourth time ")
  messages.forEach{ println("$prefix $it")}

}


fun playWithPrintMessagesWithPrefix(){
val errors = listOf("asasas","aasasasasa","asasa")
printMessageWithPrefix(errors,"azx")
}
 
  



//---------------------------

fun printErrorsCount (responses : Collection<String>) {
	
	var clientErrors = 0
	var serverErrors = 0

	responses.forEach {
	if(it.startsWith("4"))
	{
	clientErrors++
	}
	else if (it.startsWith("5"))
	serverErrors++
	}

	println(" Client errors count $clientErrors")

	println(" Server errors count $serverErrors")


}

fun playWithVariableInEnclosingScope(){
	
	val errors = listOf("403","400","401","200","500","503")

	println(printErrorsCount(errors))
}



//---------------------------


fun greeting() = "vanaaaaa"

fun playWithReference(){
	val something: () -> String = :: greeting
	println(something())


	val createPerson = ::Person
	val person = createPerson("Raj",10)

	println(person)
}


//---------------------------


fun main(){
	println("\nFunction : playWithTheFindOlderst")
	playWithTheFindOlderst()
	
	println("\nFunction : playWithLambda")
	playWithLambda()
	
	println("\nFunction : playWithCalculator")
	playWithCalculator()
	
	println("\nFunction : playWithLambdaExp")
	playWithLambdaExp()
	
	println("\nFunction : playWithPrintMessagesWithPrefix")
	playWithPrintMessagesWithPrefix()
	

	println("\nFunction : playWithVariableInEnclosingScope")
	playWithVariableInEnclosingScope()
	
	println("\nFunction :playWithReference ")
	playWithReference()
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}
