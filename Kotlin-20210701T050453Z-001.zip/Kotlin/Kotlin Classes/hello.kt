package learnkotlin

import java.util.*


fun helloworld() {
	
	println("asasa")
}

fun max(a: Int, b: Int) : Int {
	return if ( a> b) a else b
}

class Person(
    val name: String,
	val isMarried: Boolean
	)
	
class Rectangle(val height: Int, val width: Int){
val isSquare: Boolean
get(){
	return height==width
}
}

fun playWithRectangle() {
	
val rectangle = Rectangle (100,200)
println(rectangle.width)
println(rectangle.height)
println(rectangle.isSquare)
}

fun playWithRectangleRandom() : Rectangle {
  val random  = Random()
  val result: Rectangle =  Rectangle(random.nextInt(),random.nextInt())
  println(result.height)
  println(result.width)
  return result

}



fun play() {
	val person = Person("Suman",true)
	println(person.name)
	println(person.isMarried)

	val bob: Person = Person("bob",true)
	println(bob.name)
	println(bob.isMarried)



}

enum class Color(val r: Int, val g: Int, val b: Int){
	RED(255,0,0), ORANGE(255,0,0), GREEN(200,100,90),BLUE(122,222,333),
	UNKNOWN(0,0,0);
	fun rgb(): Int {
	return (r * 255 + g) * 255 + b
	}
}

fun getStringColor(color: Color): String {
	return when(color) {
	Color.RED -> "Red Color"
	Color.GREEN -> "Green Color"
	Color.BLUE -> "Blue Color"
	Color.ORANGE -> "Orange Color"
	Color.UNKNOWN -> "Iunknown Color"
	// else      -> "unknown"
	}
}


fun mixColors(c1: Color , c2: Color)  {
	when (setOf(c1,c2)){
	setOf(Color.RED, Color.BLUE) -> Color.GREEN
	setOf(Color.BLUE, Color.GREEN) -> Color.ORANGE
	else -> throw Exception("Unknown ")
	}
}

fun playWithColorMixing() {
	println(mixColors(Color.RED, Color.BLUE))
	//println(mixColors(Color.RED, Color.GREEN))
}


fun playWithFizzBuzz1() {
	for ( i in 100 downTo 1 step 2 )
	print(fizzBuzz(i))
}

fun fizzBuzz(i: Int) : String {
	return when {
	i % 15 == 0 -> "FizzBuzz"
	i % 15 == 0 -> "FizzBuzz"
	i % 15 == 0 -> "FizzBuzz"
	else -> "$i"
	}
}

fun playWithFizz(){
	for ( i in 1..100){
	println(fizzBuzz(i))
	}
}


fun playWithColors() {
	println(Color.RED)
	println(Color.RED.r)
	println(Color.RED.g)
	println(Color.RED.b)

	println(Color.RED.rgb())
	//println(Color.GREEN.rgb())
}

// MAP EXAMPLE

fun iteratingOverMaps() {
	val binaryReps = TreeMap<Char, String>()

	for( character in 'A'..'Z'){
	val binary = Integer.toBinaryString(character.code)
	binaryReps[character] = binary
	}

	for ((letter,binary) in binaryReps){
	println("Binary rep for $letter : $binary")
	}
}


fun isLetter(character: Char) : Boolean {
	if (character in 'a'..'z') return true
	if (character in 'A'..'Z') return true
	return false
}

fun playWithIsLetter() {
	println(isLetter('A'))
}

fun isLetterBest(character: Char) = character in 'a'..'z' || (character in 'A'..'Z') 

fun isNotDigit (character: Char) = character !in '0'..'9'

fun playWithIsLetterBest() {
	println(isLetter('2'))
	println(isNotDigit('2'))
	println(isNotDigit('A'))
}

//Closure Law
fun mixingColors(c1: Color,c2: Color) : Color {
	return when (setOf(c1,c2)){
	setOf(Color.RED,Color.BLUE) -> Color.GREEN
	setOf(Color.BLUE,Color.GREEN) -> Color.ORANGE
	else -> Color.UNKNOWN
	}
}

fun playWithMixingColors(){
	println(mixingColors(Color.RED,Color.BLUE))
	println(mixingColors(Color.ORANGE,Color.BLUE))
}

fun recognise(character: Char) : String {
	return when(character){
	in '0'..'9' -> "It is a digit"
	in 'a'..'z' , in 'A'..'Z' -> "it is a lettter"
	else -> "unknown character"
	}
}

fun recognise1(character: Char) =  when(character) {
	in '0'..'9' -> "It is a digit"
	in 'a'..'z' , in 'A'..'Z' -> "it is a lettter"
	else -> "unknown character"
	
}

fun playRecognise() {
	println(recognise('A'))
	println(recognise('2'))
}

fun playRecognise1() {
	println(recognise1('A'))
	println(recognise1('2'))
}


//---------------------------------
//---------------------------------Interface------------------------


interface Expr
class Num(val value: Int) : Expr
class Sum(val left: Expr, val right: Expr) : Expr

fun eval(e: Expr): Int {
	
	if(e is Num) {
	return e.value
	}

	if (e is Sum) {
	return eval(e.left) + eval(e.right)
	}

	throw IllegalArgumentException("unknow expression..")
}

fun evalIf(e: Expr): Int {
	
	if(e is Num) {
	return e.value
	}

	if (e is Sum) {
	return eval(e.left) + eval(e.right)
	}

	throw IllegalArgumentException("unknow expression..")
}

fun evaluate(e: Expr) : Int = when(e){ 
	//is Sum -> e.value
	//Need to check below line
	// is Num -> evaluate(e.left) + evaluate(e.right)
	else -> throw IllegalArgumentException("unknow expression..")
}



fun playWithEval() {
	println(eval(Sum(Num(10),Num(20))))
	println(eval(Sum(Sum(Num(10),Num(20)),Num(100))))
}


fun playWithEvaluate() {
	println(evaluate(Sum(Num(10),Num(20))))

	println(evaluate(Sum(Sum(Num(10),Num(20)),Num(100))))
}

fun typeInferencingAndBinding(){
	val somethning=10
	println(somethning)

	val somethning1: Int=10
	println(somethning1)

	var somethiingMore="hello world"
	println(somethiingMore)

	var somethiingMore1: String ="hello world1"
	println(somethiingMore1)
}







fun main() {
	println("hello world")
    helloworld()
	println(max(900,1000))
	println("calling play")
	play()
    println("calling playRec")
	playWithRectangle()
	println("calling playRecRandom")
	playWithRectangleRandom()

	playWithColors()
	println("calling fizzbuzzzzzs")

	playWithFizz()

    playWithFizzBuzz1() 
    println("calling Colors")
	 playWithColorMixing()
	 iteratingOverMaps()
	 playWithIsLetter()
	 playWithIsLetterBest()
	 playRecognise1()
	 playRecognise()
	 playWithMixingColors()
	 typeInferencingAndBinding()
	 playWithEval()
	 playWithEvaluate()
}

