package learnKotlin

data class Point(val x: Int, val y: Int){
	operator fun plus (other: Point) : Point{
	return Point(x + other.x , y + other.y)
	}
}


fun playWithPoint(){
	val point1 = Point(10,20)
	val point2= Point(102,202)

	val point3 = point1 + point2
	println(point1)
	println(point2)
	println(point3)
}

//----------------------------

data class Point1(val x: Int, val y: Int)
	
	operator fun Point1.plus (other: Point1) : Point1{
	return Point1(x + other.x , y + other.y)
	}



fun playWithPoint1(){
	val point1 = Point1(10,20)
	val point2= Point1(102,202)

	val point3 = point1 + point2
	println(point1)
	println(point2)
	println(point3)
}



//----------------------------

data class Point2(val x: Int, val y: Int)
	
	operator fun Point2.times (other: Double) : Point2{
	return Point2((x * other ) .toInt(),( y * other).toInt())
	}



fun playWithPoint2(){

	val point1 = Point2(10,20)

	println(point1 * 1.5)
}



//----------------------------


operator fun Char.times(count: Int) : String {
	return toString().repeat(count)
}

fun playWithStrings(){
	println('_'  * 80)
}



//----------------------------



data class Point3(val x: Int, val y: Int)
	
	operator fun Point3.get (other: Int) : Int{
	return when(other){
		 0 -> x
	     1 -> y
	     else  -> 
	     	throw IndexOutOfBoundsException("Invalid coordante $other")

	}

	}



fun playWithPoint3(){

	val point1 = Point3(10,20)

	println(point1[1])
	//println(point1[10])
}

//----------------------------
data class MutablePoint(var x: Int, var y: Int) 

operator fun MutablePoint.get(index: Int): Int {
    return when(index) {
        0 -> x
        1 -> y
        else -> throw IndexOutOfBoundsException("Invalid index")
    }
}

operator fun MutablePoint.set(index: Int, value: Int) {
    return when(index) {
        0 -> x = value
        1 -> y = value
        else -> throw IndexOutOfBoundsException("Invalid index")
    }
}

fun playWithMUtableValues() {
    val p = MutablePoint(10, 20)
    p[0] = 100
    p[1] = 200

    println(p[0])
    println(p[1])
}



//----------------------------


data class Point4(val x: Int, val y: Int) 

data class Rectangle(val upperLeft: Point4, val lowerRight: Point4)

operator fun Rectangle.contains(point: Point4) : Boolean {
	return point.x in upperLeft.x until lowerRight.x  && 
	       point.y in upperLeft.y until lowerRight.y
}


fun checointsInsideRect(){

	val rect= Rectangle(Point4(10,20),Point4(50,50))

	println(Point4(20,20 ) in rect)
}


//----------------------------





//----------------------------






//----------------------------


fun main() {
	

	println("\nFunction : playWithPoint")	
	playWithPoint()	

	println("\nFunction : playWithPoint1")	
	playWithPoint1()	


    println("\nFunction : playWithPoint2")	
	playWithPoint2()		

	println("\nFunction : playWithStrings")
	playWithStrings()
	

	println("\nFunction : playWithPoint3")
	playWithPoint3()
	

	println("\nFunction :playWithMUtableValues")	
	playWithMUtableValues()	
	
	println("\nFunction : checointsInsideRect ")
	checointsInsideRect()
	// println("\nFunction : ")
	// println("\nFunction : ")		
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")		
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")		
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")		
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")		
}
