package learnKotlin

interface Superpower {
	fun fly()
	fun saveWorld()
}

class BadSpiderman: Superpower {
	override fun fly() 			{ println("Fly Like Spiderman!") }
	override fun saveWorld() 	{ println("Save World Like Spiderman!") }
}

class Spiderman: Superpower {
	override fun fly() 			{ println("Fly Like Spiderman!") }
	override fun saveWorld() 	{ println("Save World Like Spiderman!") }
}

class Superman: Superpower {
	override fun fly() 			{ println("Fly Like Superman!") }
	override fun saveWorld() 	{ println("Save World Like Superman!") }
}

class Heman: Superpower {
	override fun fly() 			{ println("Fly Like Heman!") }
	override fun saveWorld() 	{ println("Save World Like Heman!") }
}

class Ironman: Superpower {
	override fun fly() 			{ println("Fly Like Ironman!") }
	override fun saveWorld() 	{ println("Save World Like Ironman!") }
}


// Inheritance
// class Huamn : Superman() {
// 	override fun fly() 				{ super.fly() }
// 	override fun saveWorld()		{ super.saveWorld() }
// }

// Composition
// Composition is Eqivalent To Inheritance
// BEST PRACTICE
// 		ALWAYS PREFER COMPOSITION OVER INHERITANCE

// Single Responsibility Design
// Open-Close Principle Design
//		Classes Should Be Open For Extension But CLose For Modification
class Huamn {
	var power : Superpower? = null
	fun fly() 			{ power?.fly() }
	fun saveWorld()		{ power?.saveWorld() }
}

class HumanNew(power: Superpower) : Superpower by power
val humannew = HumanNew (Spiderman())

fun main() {
	val human = Huamn()
	//error: type mismatch: inferred type is Spiderman but Superpower? was expected
	// human.power = BadSpiderman()
	human.power = Spiderman()
	human.fly()
	human.saveWorld()

	human.power = Superman()
	human.fly()
	human.saveWorld()

	human.power = Heman()
	human.fly()
	human.saveWorld()

	human.power = Ironman()
	human.fly()
	human.saveWorld()
}