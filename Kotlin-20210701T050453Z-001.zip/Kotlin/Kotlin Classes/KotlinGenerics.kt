package learnkotlin


val <T> List<T>.penultimate: T
    get() = this [size - 2]


fun playWithGenericProperty(){
	val list1 = listOf(10,20,30,40)
	println(list1.penultimate)


	val list2 = listOf("10","20")
	println(list2.penultimate)
}    




//-------------------------------

// Type Constraints

fun <T : Number> oneHalf(value: T) : Double {
	return value.toDouble() / 2.0

}

fun playWithTypeConstraints(){
	println(oneHalf(10))
}

//-------------------------------

fun <T :Comparable <T> > max (first: T,second: T) : T {
	return if (first > second) first else second
}

fun playWithTypeConstraints1(){
	println(max("Kotlin", "Java"))
}



//-------------------------------

fun <T> ensureTrailingPeriod(sequence: T) 
 where T: CharSequence , T: Appendable {
 	if(!sequence.endsWith('.')){
 		sequence.append('.')
 	}
 }


fun playWithTrailingPeriod(){
	val helloWorld= StringBuilder("Hello World")
	println(helloWorld)
	ensureTrailingPeriod(helloWorld)
	println(helloWorld)

}

//-------------------------------

fun printSum(collection: Collection<*>) {
    val intList = collection as? List<Int> // Elvis Operator 
    ?: throw IllegalArgumentException("List Of Int Expected") 
    println( intList.sum() ) 
} 

fun genericsTypeChecking() {
    printSum( listOf( 10, 20, 30, 40, 50 )) 
} 

fun printSumAgain(collection: Collection<Int>) {
     if (collection is List<Int>) {
          println( collection.sum() ) 
    } 
    else {
        throw IllegalArgumentException("List Of Int Expected") 
    }    
} 

fun genericsTypeCheckingl() {
     printSum( listOf( 10, 20, 30, 40, 50 )) 
}

//-------------------------------





//-------------------------------





//-------------------------------


fun main(){

	println("Calling fun : playWithGenericProperty")
	playWithGenericProperty()

    println("Calling fun : playWithTypeConstraints")
	playWithTypeConstraints()


	println("Calling fun : playWithTrailingPeriod")
    playWithTrailingPeriod()

	println("Calling fun : playWithTypeConstraints1")
	playWithTypeConstraints1()


    println("Calling fun : genericsTypeChecking1")
	genericsTypeCheckingl()

	 println("Calling fun : genericsTypeChecking")
	 genericsTypeChecking()


	
}