package learnKotlin

//_______________________________________________________________________
// Experiment With Following Code. Moment Done, RAISE HAND!

// Higher Order Function
fun buildString( builderAction : (StringBuilder) -> Unit ) : String {
	val sb = StringBuilder()
	builderAction(sb)
	return sb.toString()
}

fun playWithBuildString() {
	val string = buildString {
		it.append("Hello")
		it.append(" ")
		it.append("World!")
	}
	println(string)
}

//_______________________________________________________________________

// Experiment With Following Code. Moment Done, RAISE HAND!

// Higher Order Function
// Here Reciever Type Is StringBuilder : Extention Function Is Written For It
fun createString( builderAction : StringBuilder.() -> Unit ) : String {
	val sb = StringBuilder()
	builderAction(sb)
	return sb.toString()
}

fun playWithBuildStringWithReceiver() {
	val string1 = createString {
		this.append("Hello")
		this.append(" ")
		this.append("World!")
	}
	println(string1)

	val string2 = createString {
		append("Hey,")
		append(" ")
		append("How are you?")
	}
	println(string2)
}

//_______________________________________________________________________

// Experiment With Following Code. Moment Done, RAISE HAND!

data class Puppy(var isLiked: Boolean = false, var imageResource: Int = 0)

fun puppy(lambda: (Puppy) -> Unit) : Puppy {
  val puppy = Puppy()
  lambda(puppy)
  return puppy
}

fun playWithPuppy() {
	val result = puppy {
		it.isLiked = true
  		it.imageResource = 100
	}
	println(result)
}

fun puppyAgain(lambda: Puppy.() -> Unit): Puppy {
  val puppy = Puppy()
  puppy.lambda()
  return puppy
}

fun playWithPuppyAgain() {
	val result = puppyAgain {
		isLiked = true
  		imageResource = 100
	}
	println(result)
}

// fun puppyOnceAgain(lambda: Puppy.() -> Unit) = Puppy().apply(lambda)

//_______________________________________________________________________

// Experiment With Following Code. Moment Done, RAISE HAND!

// Domain Specific Languages
// table { 
// 	tr {
// 		td {

// 		}
// 	}
// }

open class  Tag(val name: String) {
	private val children = mutableListOf<Tag>()

	protected fun <T : Tag> doInit( child: T, init: T.() -> Unit ) {
		child.init()
		children.add(child)
	}

	override fun toString() =
		"<$name> ${ children.joinToString("") } </$name>"
}

class TABLE : Tag("table") {
	fun tr( init : TR.() -> Unit ) = doInit( TR(), init )
}

class TR : Tag("tr") {
	fun td( init : TD.() -> Unit ) = doInit( TD(), init )
}

class TD : Tag("td")

fun table( init: TABLE.() -> Unit ) = TABLE().apply( init )

fun createTable() =
	table { // Custom Domain Specific Language
		tr {
			td {

			}
		}
	}

fun playWithHTMLGenerationUsingDSL() {
	val htmlTable = createTable()
	println(htmlTable)

	// <table> 
	// 	<tr> 
	// 		<td>  </td> 
	// 	</tr> 
	// </table>
}

//_______________________________________________________________________
//_______________________________________________________________________
//_______________________________________________________________________
//_______________________________________________________________________

// Experiment With Following Code. Moment Done, RAISE HAND!

fun main() {
	
	println("\nFunction : playWithBuildString")
	playWithBuildString()

	println("\nFunction : playWithBuildStringWithReceiver")
	playWithBuildStringWithReceiver()

	println("\nFunction : playWithPuppy")
	playWithPuppy()

	println("\nFunction : playWithPuppyAgain")
	playWithPuppyAgain()

	println("\nFunction : playWithHTMLGenerationUsingDSL")
	playWithHTMLGenerationUsingDSL()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}