package learnKotlin

fun sum(x: Int, y: Int) = x + y
fun sub (x: Int, y: Int) : Int {
	return x - y
}

fun calculator(x: Int, y: Int , operation: (Int,Int) -> Int) : Int {
	return operation(x,y)
}

fun playWithCalculator(){
	val a = 20
	val b = 10

	var result = calculator(a,b, ::sum)
	println("result : $result")


}

//---------------------------

fun String.filter(predicate : (Char) -> Boolean) : String {

	val sb = StringBuilder()

	for (index in 0 until length ) {
		val element = get(index)
		if(predicate(element)) sb.append(element)
		
	}
return sb.toString()
}

fun callingFunArguments(){

	println("ab1xrfdfdf%%mmmm".filter({
		it in 'a' .. 'z'
	}))
}

//---------------------------

fun <T> Collection<T>.jointToString(
    separator: String = ", ",
    prefix: String = "",
    postfix: String = "",
    transform: (T) ->  String = { it.toString() }
	) : String {
	val result = StringBuilder(prefix)

	for((index,element)  in this.withIndex()){
		if(index > 0 ) result.append(separator)
			result.append(transform(element))
	}

	result.append(postfix)
	return result.toString()

}

fun playWithJoinToString(){
	val letters = listOf("Suman","KALYAN")

	println(letters.jointToString())




}



//---------------------------


fun stepForward(input: Int) : Int {
	return input + 1
}

fun stepBackward(input: Int) : Int {
	return input - 1
}


fun chooseStepFun(backwards: Boolean) : (Int) -> Int {
	return if(backwards) ::stepBackward else ::stepForward
}


fun moveTowardsZero(value: Int) {
	var currentValue= value
	val moveToZero = chooseStepFun (currentValue > 0 )

	//println("$currentValue")

	while(currentValue != 0){
		currentValue = moveToZero(currentValue)
		println("$currentValue")

	}
		println("done")
}

fun playWithHOF(){

	moveTowardsZero(5)
	moveTowardsZero(-5)

}
//---------------------------


//---------------------------
fun main(){

	println("Calling fun : playWithCalculator")
	playWithCalculator()

    println("Calling fun : callingFunArguments")
	callingFunArguments()


	println("Calling fun : playWithJoinToString")
	playWithJoinToString()

	println("Calling fun : playWithHOF")
	playWithHOF()



	
}
	